﻿using Infrastructure.Business.EmpBusiness;
using Infrastructure.Business.FileBusiness;
using System.Configuration;

try
{
    ILoadData loadData = new LoadData();
    IEmployeeBusiness empBusiness = new EmployeeBusiness();

    string filePath = ConfigurationManager.AppSettings["filePath"];
    var employess = loadData.LoadEmployeeFromFile(filePath).GetAwaiter().GetResult();
    var teamEmployeeInfo = empBusiness.GetTeamEmployeeInfo(employess).GetAwaiter().GetResult();

    Console.WriteLine($"Employee #1: {teamEmployeeInfo.firstEmpId}, Employee #2: {teamEmployeeInfo.secondEmpId}, ProjectId: {teamEmployeeInfo.projectId}, Days worked: {teamEmployeeInfo.daysWorked}");
}
catch (Exception e)
{
    Console.WriteLine("Exception: " + e.Message);
}