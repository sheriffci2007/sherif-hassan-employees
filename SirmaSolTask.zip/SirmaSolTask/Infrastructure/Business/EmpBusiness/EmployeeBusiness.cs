﻿using Domain.Models;

namespace Infrastructure.Business.EmpBusiness
{
    public class EmployeeBusiness : IEmployeeBusiness
    {
        public async Task<(int firstEmpId, int secondEmpId, int projectId, int daysWorked)> GetTeamEmployeeInfo(ICollection<Employee> employees)
        {
            var projectTeams = from emp in employees
                               group emp by emp.ProjectId into pro
                               select new
                               {
                                   projectId = pro.Key,
                                   proEmp = pro.Select(x => x.EmpId),
                                   daysWorked = (pro.Min(x => x.DateTo) - pro.Max(x => x.DateFrom)).Days,
                                   startDate = pro.Max(x => x.DateFrom),
                                   endDate = pro.Min(x => x.DateTo)
                               };

            var longestTeam = projectTeams.OrderByDescending(t => t.daysWorked).FirstOrDefault();
            return await Task.FromResult((longestTeam.proEmp.FirstOrDefault(), longestTeam.proEmp.Skip(1).Take(1).FirstOrDefault(), longestTeam.projectId, longestTeam.daysWorked));
        }
    }
}
