﻿using Domain.Models;

namespace Infrastructure.Business.EmpBusiness
{
    public interface IEmployeeBusiness
    {
        Task<(int firstEmpId, int secondEmpId, int projectId, int daysWorked)> GetTeamEmployeeInfo(ICollection<Employee> employees);
    }
}
