﻿using Domain.Models;

namespace Infrastructure.Business.FileBusiness
{
    public interface ILoadData
    {
        Task<ICollection<Employee>> LoadEmployeeFromFile(string filePath);
    }
}
