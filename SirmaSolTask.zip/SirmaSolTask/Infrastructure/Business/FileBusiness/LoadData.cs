﻿using Domain.Models;

namespace Infrastructure.Business.FileBusiness
{
    public class LoadData : ILoadData
    {
        public async Task<ICollection<Employee>> LoadEmployeeFromFile(string filePath)
        {
            string line;
            var employeeLst = new List<Employee>();

            StreamReader sr = new StreamReader(filePath);

            line = sr.ReadLine();

            while (line != null)
            {
                var employeeInfo = line.Split(',');
                
                var employee = new Employee()
                {
                    EmpId = Convert.ToInt32(employeeInfo[0]),
                    ProjectId = Convert.ToInt32(employeeInfo[1]),
                    DateFrom = DateTime.Parse(employeeInfo[2]),
                    DateTo = !string.IsNullOrEmpty(employeeInfo[3]) && employeeInfo[3].ToLower().Trim() != "null" ? DateTime.Parse(employeeInfo[3]) : DateTime.Parse(DateTime.Now.Date.ToString("yyyy-MM-dd"))
                };
                employeeLst.Add(employee);

                line = sr.ReadLine();
            }
            
            sr.Close();

            return await Task.FromResult(employeeLst);
        }
    }
}
